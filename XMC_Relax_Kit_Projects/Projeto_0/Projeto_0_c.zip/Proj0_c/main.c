/*
 * main.c
 *
 *  Created on: 2022 Feb 20 19:28:52
 *  Author: Luis
 */




#include "DAVE.h"                 //Declarations from DAVE Code Generation (includes SFR declaration)

XMC_VADC_RESULT_SIZE_t result;
uint8_t result_pwm, result_pwm_ant, res;


void read_adc(void) {
	result = ADC_MEASUREMENT_GetResult(&ADC_MEASUREMENT_Channel_A);
	if(result> 2200){
		result = 2200;
	}
	result_pwm_ant = result_pwm;
	res = (100 * result) /2200;

	if (res > 100) {
		res = 100;
	}
	if (res < 0) {
		res = 0;
	}
	result_pwm = result_pwm_ant * 0.9 + 0.1 * res;

	PWM_SetFreqAndDutyCycle(&PWM_0, 50, result_pwm);
}

/**

 * @brief main() - Application entry point
 *
 * <b>Details of function</b><br>
 * This routine is the application entry point. It is invoked by the device startup code. It is responsible for
 * invoking the APP initialization dispatcher routine - DAVE_Init() and hosting the place-holder for user application
 * code.
 */


int main(void)
{
  DAVE_STATUS_t status;

  status = DAVE_Init();           /* Initialization of DAVE APPs  */

  if (status != DAVE_STATUS_SUCCESS)
  {
    /* Placeholder for error handler code. The while loop below can be replaced with an user error handler. */
    XMC_DEBUG("DAVE APPs initialization failed\n");

    while(1U)
    {

    }
  }

  /* Placeholder for user application code. The while loop below can be replaced with user application code. */
  while(1U)
  {

  }
}
