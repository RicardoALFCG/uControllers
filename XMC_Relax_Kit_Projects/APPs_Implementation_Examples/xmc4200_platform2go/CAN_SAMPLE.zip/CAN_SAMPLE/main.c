/*
 * main.c
 *
 *  Created on: 2022 Mar 26 16:56:27
 *  Author: RGoncalves
 */

#include "DAVE.h"                 //Declarations from DAVE Code Generation (includes SFR declaration)
#include "main.h"


uint8_t trigger_event = 0;


int main(void)
{
  DAVE_STATUS_t status;

  status = DAVE_Init();           /* Initialization of DAVE APPs  */

  if (status != DAVE_STATUS_SUCCESS)
  {

    /* Placeholder for error handler code. The while loop below can be replaced with an user error handler. */
    XMC_DEBUG("DAVE APPs initialization failed\n");

    while(1U)
    {

    }
  }


  /* Placeholder for error handler code. The while loop below can be replaced with an user error handler. */
  XMC_DEBUG("DAVE APPs initialization failed\n");



  /* Placeholder for user application code. The while loop below can be replaced with user application code. */
  while(1U)
  {
	  if(trigger_event > 0){
		  can_routine();
		  trigger_event--;
	  }
  }
}

/*
 * This function is the Interrupt Event Handler for the CAN Node Request
 *
 */
void CAN_A_RX()
{

	CAN_NODE_STATUS_t receive_status;
	CAN_NODE_STATUS_t status;
	XMC_CAN_MO_t *MO_Ptr;
	const CAN_NODE_t *HandlePtr1 = &CAN_NODE_A;
	MO_Ptr = HandlePtr1->lmobj_ptr[0]->mo_ptr;

	status = CAN_NODE_MO_GetStatus(HandlePtr1->lmobj_ptr[0]);
	//Check receive pending status
	if ( status & XMC_CAN_MO_STATUS_RX_PENDING)
	{
	  // Clear the flag
	  XMC_CAN_MO_ResetStatus(MO_Ptr,XMC_CAN_MO_RESET_STATUS_RX_PENDING);
	  // Read the received Message object
	  receive_status = CAN_NODE_MO_Receive(HandlePtr1->lmobj_ptr[0]);
	  if (receive_status == CAN_NODE_STATUS_SUCCESS)
	  {
		  uint8_t data[8] ={0};
		  memcpy(data, &MO_Ptr->can_data[0], sizeof(MO_Ptr->can_data[0]));
		  memcpy(data + sizeof(MO_Ptr->can_data[0]), &MO_Ptr->can_data[1], sizeof(MO_Ptr->can_data[1]));


		  can_transmit(MO_Ptr->can_identifier, data, MO_Ptr->can_data_length);
		// message object receive success.
	  }
	  else
	  {
		// message object failed to receive.
	  }
	}


}


void sec_timer(){
	trigger_event++;
	update_timer();
}


void can_routine(){
	uint16_t can_id;
	uint8_t data[8] = {0, 1, 2, 3, 4, 5, 6, 7};
	uint8_t length = 8;

	//Send message every 100ms
	if(Timer_struct.miliseconds % 100 == 2){
		length = 7;
		can_id = 0x310;
		data[0] = 0x12;
		can_transmit(can_id, data, length);
	}


	//Send message every 500 second
	if(Timer_struct.miliseconds % 500 == 0){
		length = 3;
		can_id = 0x330;
		data[0] = 0x14;
		can_transmit(can_id, data, length);
	}

}

void can_transmit(uint16_t id, uint8_t *data, uint8_t length){

	XMC_CAN_MO_t *MO_Ptr;
	const CAN_NODE_t *HandlePtr1 = &CAN_NODE_A;
	MO_Ptr = HandlePtr1->lmobj_ptr[1]->mo_ptr;

	//Application code.
	MO_Ptr->can_mo_type = XMC_CAN_MO_TYPE_TRANSMSGOBJ;  //Configure message object type as transmit type
	MO_Ptr->can_id_mode = XMC_CAN_FRAME_TYPE_STANDARD_11BITS; //configure MO identifier type
	MO_Ptr->can_data_length = length; // Configure CAN transmit MO data length field
	MO_Ptr->can_identifier = id;
	MO_Ptr->can_data[0] = data[0] + (data[1]<<8) + (data[2]<<16) + (data[3]<<24);// Configure Higher 4 bytes of Data
	MO_Ptr->can_data[1] = data[4] + (data[5]<<8) + (data[6]<<16) + (data[7]<<24);  // Configure Lower 4 bytes of Data

	// Runtime change the MO configuration
	CAN_NODE_MO_Init(HandlePtr1->lmobj_ptr[1]);



	CAN_NODE_STATUS_t mo_tranmit_status;
	CAN_NODE_STATUS_t status;

	MO_Ptr = HandlePtr1->lmobj_ptr[1]->mo_ptr;
	mo_tranmit_status = CAN_NODE_MO_Transmit(HandlePtr1->lmobj_ptr[1]);

	if (mo_tranmit_status == CAN_NODE_STATUS_SUCCESS)
	{
		//message object transmission success.
		// read the TXOK status bit
		status = CAN_NODE_MO_GetStatus(HandlePtr1->lmobj_ptr[1]);

		if (status &  XMC_CAN_MO_STATUS_TX_PENDING)
		{
		  //Clear the transmit OK flag
		  XMC_CAN_MO_ResetStatus(MO_Ptr,XMC_CAN_MO_RESET_STATUS_TX_PENDING);
		}
		else
		{
		// message object failed to transmit.
		}
	}

}


void update_timer(){

	if(Timer_struct.miliseconds > 999){
		Timer_struct.miliseconds = 0;

		Timer_struct.seconds++;

		if(Timer_struct.seconds > 59){
			Timer_struct.seconds = 0;
			Timer_struct.minutes++;

			if(Timer_struct.minutes > 59){
				Timer_struct.minutes = 0;
				Timer_struct.hours++;

				if(Timer_struct.hours > 23){
					Timer_struct.hours = 0;
					Timer_struct.days++;
				}
			}
		}
	}


	Timer_struct.miliseconds++;

}

