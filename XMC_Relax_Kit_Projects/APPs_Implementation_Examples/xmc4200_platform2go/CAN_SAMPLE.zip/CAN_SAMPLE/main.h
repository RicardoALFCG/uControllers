

struct Timer_struct {
	uint16_t miliseconds; // milliseconds
	uint8_t seconds; // seconds
	uint8_t minutes; // minutes
	uint8_t hours; // hours
	uint8_t days; // days
};
struct Timer_struct Timer_struct;


void can_transmit(uint16_t id, uint8_t * data, uint8_t length);
void update_timer();
void can_routine();
